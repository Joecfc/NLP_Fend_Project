const dotenv = require('dotenv');
dotenv.config();
var textapi = process.env.API_KEY;

var path = require('path')
const express = require('express')
const mockAPIResponse = require('./mockAPI.js')
const cors = require('cors')
const fetch = require('node-fetch')
const bodyParser = require('body-parser')

const app = express()
app.use(cors())
app.use(express.static('dist'))

console.log(__dirname)

app.get('/', function (req, res) {
    res.sendFile('dist/index.html')
})

app.listen(8080, function () {
    console.log('Example app listening on port 8080!')
})
app.get('/test', function (req, res) {
    res.send(mockAPIResponse)
})
app.post('/call', callAPI)

async function callAPI(req, res) {
    console.log(`Request is ${req.body}`)
    const url = await fetch(`${baseUrl}${textapi}&lang=auto&url=${req.body}`);
    console.log(url)
    const response = await fetch(url)

    try {
        const data = await resp.json();
        res.send(data);
      } catch (err) {
        console.log("error", err);
      }
    };

