function handleSubmit(event) {
    event.preventDefault()

    // check what text was put into the form field
    let formUrl = document.getElementById('urlInput').value
    checkForName(formUrl)

    console.log("::: Form Submitted :::")
    fetch('http://localhost:8080/test')
    .then(res => res.json())
    .then(function(res) {
        document.getElementById('results').innerHTML = res.message
    })

    let apiData = await getAnalysis('http://localhost:8080/call', formText)

        // Convert response to JSON, 
        .then(apiData => apiData.json())
        //call updateUI
        .then(function (res) {
            updateUI(res)
        })
}
async function updateUI(res) {
    // GET function that takes the info from the server
    document.querySelector(' #results').innerText = ' Confidence = ' + res.confidence + '%';
    document.querySelector( '#subjectivity').innerText = res.subjectivity;
    document.querySelector(' #score').innerText =  `Polarity score: ${score(
        res.scoreTag
      )}`;
}

export const score = (scoreTag) => {
    if (scoreTag == "P+" || scoreTag == "P") {
        return  "Positive";     
    } 
    else if (scoreTag == "N+" || scoreTag == "N") {
        return  "Negative";
    } 
    else if (scoreTag == "NEU") {
        return  "Neutral";
    } 
    else {
        return  "Non-Sentimental";
    }
};

export { handleSubmit }
