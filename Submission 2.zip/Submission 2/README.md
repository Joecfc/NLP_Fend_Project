# Project Description
This project utilizes MeaningCloud's Natural Language Processing API, to determine the sentiment of content i.e. Positive/Negative.

# Installation
First, you will need to go [here](https://www.meaningcloud.com/developer/create-account). Signing up will get you an API key. 
Once you have the API key, create a file called .env in the project root folder. The file should contain:
- `API_KEY={your key here}`

`cd` into your new folder and run:
- `npm install`
It may take a while for that to install, then start the server with the following commands:
- `npm run build-dev`
- `npm run build-prod`
- `npm run start`
It should start the server automatically, then you're good to go!

