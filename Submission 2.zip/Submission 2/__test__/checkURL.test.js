import { checkURL } from '../src/client/js/urlChecker'

describe("URL validate function", () => {
    test("valid URL", () => {
        const input = 'https://google.com'
        expect(checkURL(input)).toBe(true)
    })

    test("missing protocol", () => {
        const input = 'google.com'
        expect(checkURL(input)).toBe(false)
    })

    test("reject URL with space", () => {
        const input = 'https://go ogle.com'
        expect(checkURL(input)).toBe(false)
    })
    
    test("misspelt protocol", () => {
        const input = 'htps://google.com'
        expect(checkURL(input)).toBe(false)
    })
    
    test("protocol not at start", () => {
        const input = 'google.http://com'
        expect(checkURL(input)).toBe(false)
    })

})