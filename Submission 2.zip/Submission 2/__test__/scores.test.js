
import { score } from "../src/client/js/formHandler";

describe("Text sentiment score", () => {
  test("should return true", () => {
    const scoreTag = "P+" || "P";
    expect(score(scoreTag)).toBe("Positive");
  });
  test("should return true", () => {
    const scoreTag = "NEU";
    expect(score(scoreTag)).toBe("Neutral");
  });
  test("should return true", () => {
    const scoreTag = "N+" || "N";
    expect(score(scoreTag)).toBe("Negative");
  });
  test("should return true", () => {
    const scoreTag = "NONE";
    expect(score(scoreTag)).toBe("Non Sentimental");
  });
});